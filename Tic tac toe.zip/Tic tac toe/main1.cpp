#include "tic.h"

char board[3][3] = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};
int whoseTurn = 0;

int main()
{
    cout << "Welcome to the tic-tac-toe Game!!" << endl;
    while (true)
    {
        display();
        int checkWin = turn();
        if (checkWin == 1)
        {
            cout << "Player 1 [X] Wins" << endl;
            break;
        }
        else if (checkWin == 2)
        {
            cout << "Player 2 [0] Wins" << endl;
            break;
        }
        if (isBoardFull())
        {
            cout << "It's a draw!" << endl;
            break;
        }
    }
    display();
    return 0;
}