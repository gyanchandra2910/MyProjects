#include <iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

extern int whoseTurn;
extern char board[3][3];

int generateRandomFun();
void display();
int turn();
void game(char, int);
bool checkGameWin(char);
bool isBoardFull();
