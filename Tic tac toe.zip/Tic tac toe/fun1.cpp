#include "tic.h"

void display()
{
    cout << board[0][0] << "    |    " << board[0][1] << "    |    " << board[0][2] << endl;
    cout << "-------------------" << endl;
    cout << board[1][0] << "    |    " << board[1][1] << "    |    " << board[1][2] << endl;
    cout << "-------------------" << endl;
    cout << board[2][0] << "    |    " << board[2][1] << "    |    " << board[2][2] << endl;
}

bool checkGameWin(char c)
{
    for (int i = 0; i < 3; i++)
    {
        if ((board[0][i] == c) && (board[1][i] == c) && (board[2][i] == c))
            return true;
        if ((board[i][0] == c) && (board[i][1] == c) && (board[i][2] == c))
            return true;
    }

    if ((board[0][0] == c) && (board[1][1] == c) && (board[2][2] == c))
        return true;
    else if ((board[2][0] == c) && (board[1][1] == c) && (board[0][2] == c))
        return true;
    else
        return false;
}

bool isBoardFull()
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (board[i][j] != 'X' && board[i][j] != '0')
            {
                return false;
            }
        }
    }
    return true;
}

void game(char c, int input)
{
    if (input < 1 || input > 9)
    {
        cout << "Invalid input. Please enter a number between 1 and 9." << endl;
        return; // Return early on invalid input
    }

    bool positionTaken = false;

    switch (input)
    {
    case 1:
        positionTaken = (board[0][0] == 'X' || board[0][0] == '0');
        if (!positionTaken)
            board[0][0] = c;
        break;
    case 2:
        positionTaken = (board[0][1] == 'X' || board[0][1] == '0');
        if (!positionTaken)
            board[0][1] = c;
        break;
    case 3:
        positionTaken = (board[0][2] == 'X' || board[0][2] == '0');
        if (!positionTaken)
            board[0][2] = c;
        break;
    case 4:
        positionTaken = (board[1][0] == 'X' || board[1][0] == '0');
        if (!positionTaken)
            board[1][0] = c;
        break;
    case 5:
        positionTaken = (board[1][1] == 'X' || board[1][1] == '0');
        if (!positionTaken)
            board[1][1] = c;
        break;
    case 6:
        positionTaken = (board[1][2] == 'X' || board[1][2] == '0');
        if (!positionTaken)
            board[1][2] = c;
        break;
    case 7:
        positionTaken = (board[2][0] == 'X' || board[2][0] == '0');
        if (!positionTaken)
            board[2][0] = c;
        break;
    case 8:
        positionTaken = (board[2][1] == 'X' || board[2][1] == '0');
        if (!positionTaken)
            board[2][1] = c;
        break;
    case 9:
        positionTaken = (board[2][2] == 'X' || board[2][2] == '0');
        if (!positionTaken)
            board[2][2] = c;
        break;
    default:
        cout << "Invalid input. Please enter correct input." << endl;
        return;
    }

    if (positionTaken)
    {
        cout << "Position already taken. Please enter a valid position." << endl;
        int newInput;
        cin >> newInput;
        game(c, newInput); // Ask for new input
    }
}

int turn()
{
    int input;
    if (whoseTurn == 0)
    {
        cout << "Player 1 turn [X] enter your input" << endl;
        cin >> input;
        game('X', input);
        whoseTurn = 1;
        if (checkGameWin('X') == true)
            return 1;
    }
    else
    {
        cout << "Player 2 turn [0] enter your input" << endl;
        cin >> input;
        game('0', input);
        whoseTurn = 0;
        if (checkGameWin('0') == true)
            return 2;
    }
}
